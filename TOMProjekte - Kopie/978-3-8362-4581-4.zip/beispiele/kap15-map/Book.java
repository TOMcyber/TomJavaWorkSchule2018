
public class Book {
  public String title="";
  public int published=0;

  public Book(String title, int published) {
    this.title = title;
    this.published = published;
  }
}
