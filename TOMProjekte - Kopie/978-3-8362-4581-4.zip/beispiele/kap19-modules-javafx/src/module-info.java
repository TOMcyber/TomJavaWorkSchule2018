

module info.kofler.jigsawtest {
  requires javafx.controls;
  exports info.kofler.jigsawtest;
}