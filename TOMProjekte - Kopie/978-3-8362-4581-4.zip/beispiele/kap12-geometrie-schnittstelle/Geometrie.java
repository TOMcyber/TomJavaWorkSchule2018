
public interface Geometrie {
  double berechneUmfang();
  double berechneFlaeche();
}
