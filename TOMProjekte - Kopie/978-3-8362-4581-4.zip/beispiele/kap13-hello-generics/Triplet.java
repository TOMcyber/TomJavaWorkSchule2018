
public class Triplet<T> {
  public T a, b, c;
  
  // Konstruktur
  public Triplet(T data1, T data2, T data3) {
    a = data1;
    b = data2;
    c = data3;
  }
}
