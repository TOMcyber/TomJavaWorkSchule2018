class Rectangle {
  public int w, h;
  public Rectangle(int w, int h) {
    this.w = w;
    this.h = h; 
  }
}