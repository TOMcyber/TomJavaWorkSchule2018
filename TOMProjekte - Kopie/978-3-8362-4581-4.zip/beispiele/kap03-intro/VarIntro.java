// kap02-intro
// Einführungsbeispiel Variablen
public class VarIntro {
  public static void main(String[] args) {
    double breite=10.5;
    double laenge=17.3;
    double umfang=(laenge+breite)*2;
    double flaeche=laenge*breite;
    System.out.println("Umfang: " + umfang);
    System.out.println("Fläche: " + flaeche);
  }
}
