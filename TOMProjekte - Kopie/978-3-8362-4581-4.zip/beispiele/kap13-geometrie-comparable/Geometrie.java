
public interface Geometrie extends Comparable<Geometrie>{
  double berechneUmfang();
  double berechneFlaeche();
}
