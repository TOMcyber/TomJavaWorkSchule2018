
public class EncodingTest {

  public static void main(String[] args) {
    String s="äöüß";
    System.out.println(s);
  }

}
