/**
 * Created by kofler on 09.12.16.
 */
public class Track {
  String title;
  String mp3fname;
  double length;

  public Track(String title, String mp3fname, double length) {
    this.title = title;
    this.mp3fname = mp3fname;
    this.length = length;
  }
}
